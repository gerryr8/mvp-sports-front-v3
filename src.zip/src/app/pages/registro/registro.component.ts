import { Component, OnInit } from '@angular/core';
import {RegistroService} from "../../services/registro.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent implements OnInit {


  users: any;

  constructor(private registroService: RegistroService, private router: Router) {
    this.registroService.products().subscribe((data) =>{
      this.users=data;
    });
  }

  redirectToCategoriesPage(){
    this.router.navigate(['pages/categorias']);
  }

  saveUser(data:any)
  {
    console.warn(data)
    this.registroService.saveUser(data).subscribe((result) =>{
      console.warn(result)
      this.redirectToCategoriesPage();
    });
  }


  ngOnInit(): void {
  }

}
