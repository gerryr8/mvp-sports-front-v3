import { Component, OnInit } from '@angular/core';
import {Product} from "../../models/product";
import {ProductosService} from "../../services/products/productos.service";
import {Categories} from "../../models/categories";
import {CategoryService} from "../../services/category.service";

@Component({
  selector: 'app-categorias',
  templateUrl: './categorias.component.html',
  styleUrls: ['./categorias.component.css']
})
export class CategoriasComponent implements OnInit {

  categories: Categories[];


  constructor(private categoryService :CategoryService) {
  }

  ngOnInit(): void {
    this.getCategoriesList();
  }

  private getCategoriesList() {
    this.categoryService.getCategories().subscribe(data => {
      this.categories = data;
    });

  }

}
