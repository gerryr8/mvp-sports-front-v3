import { Component, OnInit } from '@angular/core';
import {Product} from "../../models/product";
import {AddproductService} from "../../services/addproduct.service";
import {Router} from "@angular/router";
import {RegistroService} from "../../services/registro.service";
import {error} from "@angular/compiler/src/util";
import {Categories} from "../../models/categories";
import {CategoryService} from "../../services/category.service";


@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  products: any;

  constructor(private addproductService: AddproductService, private router:Router, private categoryService :CategoryService ) {
    this.addproductService.products().subscribe((data) =>{
      this.products=data;
    });
  }


  redirectToSuccessPage(){
    this.router.navigate(['pages/success']);
    console.log("Produco agregado exitosamente");
  }

  saveAproduct(datas:any)
  {
    console.warn(datas)
    this.addproductService.saveAproduct(datas).subscribe((results) =>{
      this.redirectToSuccessPage();
      console.warn(results)
    });
  }


  categories: Categories[];



  ngOnInit(): void {
    this.getCategoriesList();
  }

  private getCategoriesList() {
    this.categoryService.getCategories().subscribe(data => {
      this.categories = data;
    });

  }













  /*

    product: Product = new Product();
    constructor(private addproductService: AddproductService, private router:Router) { }

    ngOnInit(): void {
    }

    saveProduct(){
      this.addproductService.addProduct(this.product).subscribe(data => {
        console.log(data);
        //this.redirectToCategoriesPage();
      }, error => console.log(error));
    }

    //redirectToCategoriesPage(){
    //  this.router.navigate(['pages/categorias']);
    //}
    onSubmit(){
      console.log(this.products);
      this.saveProduct();
    }
    /*
   */

}
