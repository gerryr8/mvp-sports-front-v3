import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CategoriasComponent } from '../pages/categorias/categorias.component';
import { InicioComponent } from '../pages/inicio/inicio.component';
import { LearnmoreComponent } from '../pages/learnmore/learnmore.component';
import { LoginComponent } from './login/login.component';
import { RegistroComponent } from '../pages/registro/registro.component';
import {AddproductComponent} from "../pages/addproduct/addproduct.component";
import {SuccessComponent} from "../pages/success/success.component";
import {CarouselComponent} from "../pages/carousel/carousel.component";

const routes: Routes = [
  {
    path:'',
    component:LoginComponent
  },{
    path:'pages/inicio',
    component:InicioComponent
  },{
    path:'pages/login',
    component:LoginComponent
  },{
    path:'pages/registro',
    component:RegistroComponent
  },{
    path:'pages/learnmore',
    component:LearnmoreComponent
  },{
    path:'pages/categorias',
    component:CategoriasComponent
  },{
    path:'pages/addproduct',
    component:AddproductComponent
  },
  {
    path:'pages/success',
    component:SuccessComponent
  },
  {
    path: 'pages/carousel',
    component: CarouselComponent
  },
  {
    path: 'pages/registro',
    component: RegistroComponent
  },
  {
    path:'**',
    redirectTo:'pages/login'
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports:[
    RouterModule
  ]
})
export class AppRoutingModule { }
