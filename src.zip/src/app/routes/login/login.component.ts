import { Component, OnInit } from '@angular/core';
import {RegistroService} from "../../services/registro.service";
import {LoginService} from "../../services/login.service";
import {Router} from "@angular/router";
import {Users} from "../../models/users";
import {empty} from "rxjs";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  customers: any;

  role :Users;

  constructor(private loginService : LoginService, private router:Router) {
    this.loginService.customers().subscribe((data) =>{
      this.customers=data;
    });
  }

  redirectToCategoriesPage(){
    this.router.navigate(['pages/categorias']);
  }

  redirectToAddproductPage(){
    this.router.navigate(['pages/addproduct']);
  }

  saveUser(data:any){
      console.warn(data)
    //this.loginService.saveUser(data).subscribe((result) => {
   //   console.warn(result){
    {
      this.redirectToCategoriesPage()
    };

        //this.redirectToAddproductPage();
    }


  ngOnInit(): void {
  }

}
