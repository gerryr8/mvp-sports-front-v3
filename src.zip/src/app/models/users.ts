export class Users {
  customer_id: number;
  full_name: string;
  email: string;
  password: string;
  username: string;
  phone: number;
  country: string;
  shipping_address: string;
  role: string;
}
