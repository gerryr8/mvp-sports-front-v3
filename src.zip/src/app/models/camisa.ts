export class Camisa {

  id: number;
  product_number: number;
  name: string;
  price: number;
  stock: number;
  description: string;
  thumbnail: string;
  image: string;
  weight: number;
  category: string;
  id_category: number;



}
