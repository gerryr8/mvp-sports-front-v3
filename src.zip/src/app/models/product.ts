
export class Product {

  product_number: number;
  name: string;
  price: number;
  stock: number;
  description: string;
  thumbnail: string;
  image: string;
  weight: number;
  id_category: number;



}
