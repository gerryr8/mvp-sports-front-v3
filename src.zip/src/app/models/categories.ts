export class Categories{
  id_category: number;
  category_name: string;
}
