import { Component, OnInit } from '@angular/core';
import { Product} from "../../models/product";
import {ProductosService} from "../../services/products/productos.service";


@Component({
  selector: 'app-articulo',
  templateUrl: './articulo.component.html',
  styleUrls: ['./articulo.component.css']
})
export class ArticuloComponent implements OnInit {


  products: Product[];
  images: Product[];

categories: any;

  constructor(private productosService: ProductosService ) { }

  ngOnInit(): void {
    this.getAllProducts()
  }

  private getAllProducts() {
    this.productosService.getAllProducts().subscribe(data => {
      this.products = data;
    });
  }


    /*
    this.categories = [{
      "cname":"Tenis"
    },
      {
        "cname":"Camisas"
      }];
/*/


  }




