import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DarkSideBarComponent } from './dark-side-bar.component';

describe('DarkSideBarComponent', () => {
  let component: DarkSideBarComponent;
  let fixture: ComponentFixture<DarkSideBarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DarkSideBarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DarkSideBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
