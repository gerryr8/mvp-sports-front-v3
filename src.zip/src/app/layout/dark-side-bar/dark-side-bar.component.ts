import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dark-side-bar',
  templateUrl: './dark-side-bar.component.html',
  styleUrls: ['./dark-side-bar.component.css']
})
export class DarkSideBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
