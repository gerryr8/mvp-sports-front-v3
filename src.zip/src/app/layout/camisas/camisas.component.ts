import { Component, OnInit } from '@angular/core';
import {Camisa} from "../../models/camisa";
import {CamisaService} from "../../services/productos/camisa.service";

@Component({
  selector: 'app-camisas',
  templateUrl: './camisas.component.html',
  styleUrls: ['./camisas.component.css']
})
export class CamisasComponent implements OnInit {

  camisas: Camisa[];
  images: Camisa[];

  categories: any;

  constructor(private camisaService: CamisaService ) { }

  ngOnInit(): void {
    this.getListaCamisas()
  }

  private getListaCamisas() {
    this.camisaService.getCamisas().subscribe(data => {
      this.camisas = data;
    });
  }


}
