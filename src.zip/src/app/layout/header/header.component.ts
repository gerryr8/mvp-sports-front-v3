import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  rutas=[
    {
      name:"Inicio",
      path: "pages/inicio"
    },
    {
      name:"LearnMore",
      path: "pages/learnmore"
    },
    {
      name:"Categorias",
      path: "pages/categorias"
    },
    {
      name:"Login",
      path: "pages/login"
    },
    {
      name:"añadirProducto",
      path: "pages/addproduct"
    }
  ];


  constructor() { }

  ngOnInit(): void {
  }

}
