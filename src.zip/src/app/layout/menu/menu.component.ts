import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  rutas=[
    {
      name:"Inicio",
      path: "pages/inicio"
    },
    {
      name:"LearnMore",
      path: "pages/learnmore"
    },
    {
      name:"Categorias",
      path: "pages/categorias"
    },
    {
      name:"Login",
      path: "pages/login"
    },
    {
      name:"añadirProducto",
      path: "pages/addproduct"
    }
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
