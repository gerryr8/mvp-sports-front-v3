import { Component, OnInit } from '@angular/core';
import {Tenis} from "../../models/tenis";
import {ProductosService} from "../../services/products/productos.service";
import {TenisService} from "../../services/productos/tenis.service";

@Component({
  selector: 'app-tenis',
  templateUrl: './tenis.component.html',
  styleUrls: ['./tenis.component.css']
})
export class TenisComponent implements OnInit {


  tenisS: Tenis[];
  images: Tenis[];

  categories: any;

  constructor(private tenisService: TenisService ) { }

  ngOnInit(): void {
    this.getListaTenis()
  }

  private getListaTenis() {
    this.tenisService.getTenis().subscribe(data => {
      this.tenisS = data;
    });
  }

}
