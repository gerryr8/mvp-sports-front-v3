import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dark-header',
  templateUrl: './dark-header.component.html',
  styleUrls: ['./dark-header.component.css']
})
export class DarkHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
