import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Product} from "../models/product";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class RegistroService {


  pURL = 'http://localhost:8082/usuario';

  constructor(private httpCLient: HttpClient) { }

  products(){
    return this.httpCLient.get(this.pURL)
  }

  saveUser(data: any){
    return this.httpCLient.post(this.pURL, data)
  }

}
