import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class LoginService {


  LURL = 'http://localhost:8082/usuario';

  constructor(private httpCLient: HttpClient) {
  }

  customers() {
    return this.httpCLient.get(this.LURL)
  }

  saveUser(data: any) {
    return this.httpCLient.post(this.LURL, data)
  }
}
