import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Camisa} from "../../models/camisa";

@Injectable({
  providedIn: 'root'
})
export class CamisaService {

  //lista de camisas
  private URL = "http://localhost:8082/api/v1/products/findByCategory?category=2";

  constructor(private httpCLient: HttpClient) { }

  getCamisas():Observable<Camisa[]>{
    return this.httpCLient.get<Camisa[]>(this.URL);
  }


}
