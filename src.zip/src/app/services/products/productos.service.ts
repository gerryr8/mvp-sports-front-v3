import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Product} from "../../models/product";

@Injectable({
  providedIn: 'root'
})
export class ProductosService {

  //lista de todos los productos
  private AURL = "http://localhost:8082/api/v1/products/categorieslist";

  constructor(private httpCLient: HttpClient) { }

  getAllProducts():Observable<Product[]>{
    return this.httpCLient.get<Product[]>(this.AURL);
  }




}
