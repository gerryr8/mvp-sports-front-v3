import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Product} from "../models/product";
import {Categories} from "../models/categories";

@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  private CURL = "http://localhost:8082/api/v1/products/categories";

  constructor(private httpCLient: HttpClient) { }

  getCategories():Observable<Categories[]>{
    return this.httpCLient.get<Categories[]>(this.CURL);
  }
}
