import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Product} from "../models/product";

@Injectable({
  providedIn: 'root'
})
export class AddproductService {

  //añadir producto
  private pURL = "http://localhost:8082/api/v1/products/add";

  constructor(private httpCLient: HttpClient) { }

  //post para agregar producto
  addProduct(product:Product):Observable<Object>{
    return this.httpCLient.post(this.pURL, product);
  }

  products(){
    return this.httpCLient.get(this.pURL)
  }

  saveAproduct(data: any){
    return this.httpCLient.post(this.pURL, data)

  }



}
