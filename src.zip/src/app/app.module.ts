import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './routes/app-routing.module';
import { AppComponent } from './app.component';
import { InicioComponent } from './pages/inicio/inicio.component';
import { LoginComponent } from './routes/login/login.component';
import { RegistroComponent } from './pages/registro/registro.component';
import { LearnmoreComponent } from './pages/learnmore/learnmore.component';
import { CategoriasComponent } from './pages/categorias/categorias.component';
import { MenuComponent } from './layout/menu/menu.component';
import { ArticuloComponent } from './layout/articulo/articulo.component';
import { FlexComponent } from './layout/flex/flex.component';
import { HeaderComponent } from './layout/header/header.component';
import { SideBarComponent } from './layout/side-bar/side-bar.component';
import { AddproductComponent } from './pages/addproduct/addproduct.component';
import { DarkHeaderComponent } from './layout/dark-header/dark-header.component';
import { DarkSideBarComponent } from './layout/dark-side-bar/dark-side-bar.component';
import {HttpClientModule} from "@angular/common/http";
import {FormsModule} from "@angular/forms";
import { SuccessComponent } from './pages/success/success.component';
import { CarouselComponent } from './pages/carousel/carousel.component';
import { TenisComponent } from './layout/tenis/tenis.component';
import { CamisasComponent } from './layout/camisas/camisas.component';

@NgModule({
  declarations: [
    AppComponent,
    InicioComponent,
    LoginComponent,
    RegistroComponent,
    LearnmoreComponent,
    CategoriasComponent,
    MenuComponent,
    ArticuloComponent,
    FlexComponent,
    HeaderComponent,
    SideBarComponent,
    AddproductComponent,
    DarkHeaderComponent,
    DarkSideBarComponent,
    SuccessComponent,
    CarouselComponent,
    TenisComponent,
    CamisasComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
